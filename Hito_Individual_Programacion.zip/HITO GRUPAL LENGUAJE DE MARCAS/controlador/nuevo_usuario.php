<?php
    include("../vista/header_login.php");   
    include("../vista/form_nuevo_usuario.php");
    
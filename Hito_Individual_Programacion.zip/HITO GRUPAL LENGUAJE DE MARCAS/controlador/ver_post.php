<?php
    include("../vista/post.php");
